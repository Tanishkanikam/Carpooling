<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign In</title>
    <link rel="stylesheet" type="text/css" href="css/sign.css">
    <script>
        function checkCredentials() {
            // Get the entered username and password
            var username = document.getElementById('username').value;
            var password = document.getElementById('password').value;
            
            // Here you should perform a check whether the credentials are valid
            // For demonstration purposes, let's assume they are invalid if both fields are not filled
            if (!username || !password) {
                // If both fields are not filled, show the pop-up asking user to register first
                alert("Please register first!");
                // Prevent form submission
                return false;
            }
            // If the credentials are valid, the form will be submitted as usual
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Sign In</h2>
        <form id="signin-form" action="signin.php" method="post" onsubmit="return checkCredentials()">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>
            <input type="submit" value="Sign In">
        </form>
        <p>Don't have an account? <a href="signup.html">Register here</a>.</p>
    </div>
</body>
</html>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Access form data
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Validate credentials or perform authentication
    // For demonstration purposes, let's just echo them
    echo "Username: $username<br>";
    echo "Password: $password<br>";
}
?>
